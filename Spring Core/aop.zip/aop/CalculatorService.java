package com.hcl.aop;

import org.springframework.stereotype.Component;

@Component
public class CalculatorService {
	public int add(int a, int b) {
		System.out.println("Inside add() method.");
		return a + b;
	}
}
