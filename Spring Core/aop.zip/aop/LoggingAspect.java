package com.hcl.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	@Before("execution(* com.hcl.aop.CalculatorService.add(..))")
	public void logBefore() {
		System.out.println("LoggingAspect: About to call add()");
	}

	// After Advice
	@After("execution(* com.hcl.aop.CalculatorService.add(..))")
	public void logAfter(JoinPoint joinPoint) {
		System.out.println("[After] Method executed: " + joinPoint.getSignature().getName());
	}

	// After Returning Advice
	@AfterReturning(pointcut = "execution(* com.hcl.aop.CalculatorService.add(..))", returning = "result")
	public void logAfterReturning(Object result) {
		System.out.println("[AfterReturning] Method returned: " + result);
	}

	

	@AfterThrowing(pointcut = "execution(* com.hcl.aop.CalculatorService.add(..))", throwing = "ex")
	public void logAfterThrowing(Exception ex) {
		System.out.println("[AfterThrowing] Exception occurred: " + ex.getMessage());
	}

}
