package com.hcl.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AppMain {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		CalculatorService calculator = context.getBean(CalculatorService.class);
		int result = calculator.add(5, 3);
		System.out.println("Result: " + result);
	}
}
