package com.coforge.autoconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ComponentScan("com.coforge.autoconfig")
public class AppConfig {

	@Bean(name = "homeAddress")
	//@Bean
	public Address homeAddress() {
		Address address = new Address();
		address.setAddressLine1("MG Road");
		address.setCity("Bangalore");
		address.setState("Karnataka");
		address.setCountry("India");
		return address;
	}

	@Bean(name = "officeAddress")
	//@Bean
	//@Primary
	public Address officeAddress() {
		Address address = new Address();
		address.setAddressLine1("CP");
		address.setCity("New Delhi");
		address.setState("Delhi");
		address.setCountry("India");
		return address;
	}

	@Bean
	public Employee employee() {
		Employee employee = new Employee();
		employee.setId(1);
		employee.setName("Vijay");
		// employee.setAddress(address());
		return employee;

	}

}
