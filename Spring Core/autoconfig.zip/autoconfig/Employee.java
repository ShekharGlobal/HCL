package com.coforge.autoconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;




@Component
public class Employee {

    private int id;
    private String name;

    @Autowired
    @Qualifier("homeAddress")
    private Address homeAddress;

    @Autowired
    @Qualifier("officeAddress")
    private Address officeAddress;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(Address homeAddress) {
        this.homeAddress = homeAddress;
    }

    public Address getOfficeAddress() {
        return officeAddress;
    }

    public void setOfficeAddress(Address officeAddress) {
        this.officeAddress = officeAddress;
    }

    public void display() {
        System.out.println(id + " " + name);
        System.out.println("Home Address: " + homeAddress);
        System.out.println("Office Address: " + officeAddress);
    }
}
