package com.hcl.abs;

public  class Maruti extends Car {

	@Override
	public void milage() {
		System.out.println("20KMPL");
	}

	

	

}
