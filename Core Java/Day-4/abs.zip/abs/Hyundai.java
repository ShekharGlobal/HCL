package com.hcl.abs;

public class Hyundai extends Car{

	@Override
	public void milage() {
		System.out.println("15KMPL");
		
	}

}
